# Código inicial para el ejemplo del video de youtube sobre el uso de Google Maps

Espero que todo esta información te sea muy útil!

No te olvides seguirme en YouTube o visitar mis cursos en Udemy

YouTube
https://www.youtube.com/channel/UCuaPTYj15JSkETGnEseaFFg

Udemy
https://www.udemy.com/user/550c38655ec11/
