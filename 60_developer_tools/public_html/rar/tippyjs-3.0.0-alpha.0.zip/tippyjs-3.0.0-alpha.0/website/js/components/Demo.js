import { h } from 'hyperapp'
import logo from '../../assets/img/logo.svg'
import Tippy from './Tippy'
import Emoji from './Emoji'

const ANIMATIONS = [
  'shift-away',
  'shift-toward',
  'perspective',
  'fade',
  'scale'
]

const printValue = value =>
  Array.isArray(value) ? `[${value.join(', ')}]` : value

export default () => (
  <section class="section" id="demo">
    <h2 class="section__heading">Tippy's features</h2>
    <div class="feature">
      <h3 class="feature__heading">Default</h3>
      <p>
        The default tippy tooltip looks like this when given no options. It has
        a nifty backdrop filling animation!
      </p>
      <Tippy content="I'm the default tooltip!">
        <button class="btn">Try me!</button>
      </Tippy>
    </div>

    <div class="feature">
      <Emoji class="feature__icon">↕️</Emoji>
      <h3 class="feature__heading">Placement</h3>
      <p>
        A tooltip can be placed in four different ways in relation to its
        reference element. Additionally, the tooltip be shifted.
      </p>
      {['top', 'bottom', 'left', 'right'].map(placement => (
        <Tippy placement={placement}>
          <button class="btn">
            {placement[0].toUpperCase() + placement.slice(1)}
          </button>
        </Tippy>
      ))}
    </div>

    <div class="feature">
      <Emoji class="feature__icon">▶️</Emoji>
      <h3 class="feature__heading">Arrows</h3>
      <p>
        Arrows point toward the reference element. There are two different types
        of arrows: sharp and round. You can transform the proportion and scale
        of the arrows any way you like.
      </p>
      <Tippy arrow={true} animation="fade">
        <button class="btn">Default</button>
      </Tippy>
      <Tippy arrow={true} arrowType="round" animation="fade">
        <button class="btn">Round</button>
      </Tippy>
      <Tippy arrow={true} arrowTransform="scaleX(1.5)" animation="fade">
        <button class="btn">Wide</button>
      </Tippy>
      <Tippy arrow={true} arrowTransform="scaleX(0.75)" animation="fade">
        <button class="btn">Skinny</button>
      </Tippy>
      <Tippy arrow={true} arrowTransform="scale(0.75)" animation="fade">
        <button class="btn">Small</button>
      </Tippy>
      <Tippy arrow={true} arrowTransform="scale(1.35)" animation="fade">
        <button class="btn">Large</button>
      </Tippy>
    </div>

    <div class="feature">
      <Emoji class="feature__icon">👏</Emoji>
      <h3 class="feature__heading">Triggers</h3>
      <p>Triggers define the types of events that cause a tooltip to show.</p>
      <Tippy trigger="mouseenter">
        <button class="btn">Hover or touch</button>
      </Tippy>
      <Tippy trigger="focus">
        <button class="btn">Focus or touch</button>
      </Tippy>
      <Tippy trigger="click">
        <button class="btn">Click</button>
      </Tippy>
    </div>

    <div class="feature">
      <Emoji class="feature__icon">✍️</Emoji>
      <h3 class="feature__heading">Interactivity</h3>
      <p>
        Tooltips can be interactive, meaning they won't hide when you hover over
        or click on them.
      </p>
      <Tippy interactive={true}>
        <button class="btn">Interactive (hover)</button>
      </Tippy>
      <Tippy interactive={true} trigger="click">
        <button class="btn">Interactive (click)</button>
      </Tippy>
    </div>

    <div class="feature">
      <Emoji class="feature__icon">💫</Emoji>
      <h3 class="feature__heading">Animations</h3>
      <p>Tooltips can have different types of animations.</p>
      {ANIMATIONS.map(animation => (
        <Tippy animation={animation} arrow={true}>
          <button class="btn">
            {animation[0].toUpperCase() + animation.slice(1)}
          </button>
        </Tippy>
      ))}
      {ANIMATIONS.filter(animation => animation !== 'fade').map(animation => (
        <Tippy
          animation={animation}
          duration={[600, 300]}
          inertia={true}
          arrow={true}
        >
          <button class="btn">
            Inertia ({animation[0].toUpperCase() + animation.slice(1)})
          </button>
        </Tippy>
      ))}
    </div>

    <div class="feature">
      <Emoji class="feature__icon">⏱️</Emoji>
      <h3 class="feature__heading">Duration</h3>
      <p>A tippy can have different transition durations.</p>
      {[0, 200, 1000, [250, 1000], [1000, 500]].map(duration => (
        <Tippy duration={duration}>
          <button class="btn">{printValue(duration)}</button>
        </Tippy>
      ))}
    </div>

    <div class="feature">
      <Emoji class="feature__icon">⏳</Emoji>
      <h3 class="feature__heading">Delay</h3>
      <p>
        Tooltips can delay showing or{' '}
        <Tippy.secondary content="*Hide delay is always 0 on touch devices for UX reasons">
          <span class="tippy" tabindex="0">
            hiding*
          </span>
        </Tippy.secondary>{' '}
        after a trigger.
      </p>
      {[0, 200, 800, [800, 0], [200, 800]].map(delay => (
        <Tippy delay={delay}>
          <button class="btn">{printValue(delay)}</button>
        </Tippy>
      ))}
    </div>

    <div class="feature">
      <Emoji class="feature__icon">🖼️</Emoji>
      <h3 class="feature__heading">HTML</h3>
      <p>
        Tooltips can contain HTML, allowing you to craft awesome interactive
        popovers.
      </p>
      <Tippy
        appendTo={el => el.parentNode}
        interactive={true}
        theme="light rounded"
        arrow={true}
        size="large"
        arrowTransform="scale(2)"
        distance={15}
        interactiveBorder={20}
        content={
          <div class="template" style={{ padding: '20px' }}>
            <img width="100" src={logo} />
            <h3>
              Look! The tippy logo is inside a <strong>tippy</strong>.
            </h3>
            <button
              class="btn"
              onclick={e => e.target.closest('.tippy-popper')._tippy.hide()}
            >
              Close
            </button>
          </div>
        }
      >
        <button class="btn">HTML Templates</button>
      </Tippy>
    </div>

    <div class="feature">
      <Emoji class="feature__icon">🖌️</Emoji>
      <h3 class="feature__heading">Themes</h3>
      <p>
        A tippy can have any kind of theme you want! Creating a custom theme is
        a breeze.
      </p>
      <Tippy content="See-though!" theme="translucent">
        <button class="btn">Translucent</button>
      </Tippy>
      <Tippy content="Nice n' light" theme="light" arrow={true}>
        <button class="btn">Light</button>
      </Tippy>
      <Tippy content="Awesome colors!" theme="gradient">
        <button class="btn">Gradient</button>
      </Tippy>
    </div>

    <div class="feature">
      <Emoji class="feature__icon">😍</Emoji>
      <h3 class="feature__heading">Misc</h3>
      <p>
        Tippy has a ton of{' '}
        <Tippy.secondary
          interactive={true}
          content={
            <div>
              Missing a feature you need? Submit a{' '}
              <a
                class="is-white"
                href="https://github.com/atomiks/tippyjs/issues"
                target="_blank"
              >
                feature request
              </a>{' '}
              on the GitHub repo!
            </div>
          }
        >
          <span class="tippy" tabindex="0">
            features
          </span>
        </Tippy.secondary>, and it's constantly improving.
      </p>
      <Tippy
        content="How cool's this?!"
        followCursor={true}
        arrow={true}
        animation="fade"
      >
        <button class="btn">Follow cursor</button>
      </Tippy>
      <Tippy
        content="You'll need a touch device for this one."
        touchHold={true}
      >
        <button class="btn">Touch &amp; Hold</button>
      </Tippy>
      <Tippy content="I'm hugging the tooltip!" distance={0} animation="fade">
        <button class="btn">Distance</button>
      </Tippy>
      <Tippy
        content="I'm hugging the tooltip!"
        offset="10, 50"
        animation="fade"
      >
        <button class="btn">Offset</button>
      </Tippy>
      <Tippy size="small">
        <button class="btn">Small</button>
      </Tippy>
      <Tippy size="large">
        <button class="btn">Large</button>
      </Tippy>
    </div>
  </section>
)
