```html
<button data-tippy="I'm a tooltip!">Text</button>
```
