```js
tippy(list, {
  appendTo(ref) {
    return ref.parentNode
  }
})
```
