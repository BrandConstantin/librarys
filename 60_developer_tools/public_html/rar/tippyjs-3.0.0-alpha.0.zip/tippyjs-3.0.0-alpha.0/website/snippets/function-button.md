```html
<button>Text</button>
```
