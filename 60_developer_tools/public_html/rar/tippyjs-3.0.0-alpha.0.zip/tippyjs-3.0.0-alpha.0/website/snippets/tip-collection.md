```js
{
  // Targets that should receive a tippy
  targets: '.btn',

  // Default props + options merged together
  props: { ... },

  // Array of all instances that were created
  instances: [tip, tip, tip, ...],

  // Method to destroy all the tooltips that were created
  destroyAll() { ... }
}
```
