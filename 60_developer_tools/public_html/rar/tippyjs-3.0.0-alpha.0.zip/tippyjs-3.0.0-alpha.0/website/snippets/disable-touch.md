```js
// Disable the tooltip on touch devices
tip.disableTouch()
```
