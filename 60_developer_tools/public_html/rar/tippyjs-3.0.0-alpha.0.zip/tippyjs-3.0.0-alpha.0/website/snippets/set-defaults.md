```js
tippy.setDefaults({
  arrow: true,
  arrowType: 'round',
  duration: 0
})
```
