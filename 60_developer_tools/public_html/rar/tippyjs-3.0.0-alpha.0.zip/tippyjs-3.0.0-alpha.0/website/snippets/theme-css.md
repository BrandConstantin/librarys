```css
/* If `animateFill: true` (default) */
.tippy-tooltip.honeybee-theme .tippy-backdrop {
  background-color: yellow;
  font-weight: bold;
  color: #333;
}

/* If `animateFill: false` */
.tippy-tooltip.honeybee-theme {
  background-color: yellow;
  border: 2px solid orange;
  font-weight: bold;
  color: #333;
}
```
