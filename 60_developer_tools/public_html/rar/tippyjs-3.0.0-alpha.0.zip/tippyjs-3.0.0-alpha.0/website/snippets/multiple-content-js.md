```js
tippy('.btn', {
  animation: 'shift-toward',
  arrow: true,
  delay: 50
})
```
