```js
tippy('.btn', {
  theme: 'honeybee'
})
```
