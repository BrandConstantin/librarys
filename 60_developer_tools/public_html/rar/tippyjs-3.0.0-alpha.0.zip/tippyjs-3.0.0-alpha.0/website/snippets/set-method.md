```js
tip.set({
  content: 'New content',
  arrow: true,
  duration: 1000,
  animation: 'perspective'
})
```
