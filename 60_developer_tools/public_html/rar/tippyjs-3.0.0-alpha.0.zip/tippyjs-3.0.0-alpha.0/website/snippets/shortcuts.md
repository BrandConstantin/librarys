```js
// The popper element has the instance attached to it:
popper._tippy
// As does the reference element (as seen above):
reference._tippy
```
