```js
tippy('#parent', {
  content: 'Shared content',
  target: '.child'
})
```
