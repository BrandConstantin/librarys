```html
<button
  class="btn"
  data-tippy="I'm a Tippy tooltip!"
  data-tippy-delay="50"
  data-tippy-arrow="true"
  data-tippy-animation="shift-toward"
>
  Text
</button>
```
