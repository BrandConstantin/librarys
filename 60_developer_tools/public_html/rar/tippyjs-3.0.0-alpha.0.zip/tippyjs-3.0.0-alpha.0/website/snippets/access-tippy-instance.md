```js
tippy('.btn')
const btn = document.querySelector('.btn')
const tip = btn._tippy
```
