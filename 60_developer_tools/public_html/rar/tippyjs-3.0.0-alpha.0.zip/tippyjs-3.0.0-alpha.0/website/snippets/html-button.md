```html
<button class="btn">Text</button>
```
