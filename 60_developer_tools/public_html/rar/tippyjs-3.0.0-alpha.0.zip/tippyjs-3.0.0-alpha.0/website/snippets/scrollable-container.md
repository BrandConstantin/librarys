```js
tippy('.mySelector', {
  popperOptions: {
    modifiers: {
      preventOverflow: { enabled: false },
      hide: { enabled: false }
    }
  }
})
```
