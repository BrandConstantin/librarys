```html
<button class="btn">Text</button>
<div id="myTemplate">
  My HTML <strong style="color: pink;">tooltip</strong> content
</div>
```
