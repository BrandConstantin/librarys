```js
tippy('.btn', {
  content: "I'm a tooltip!",
  delay: 100,
  arrow: true,
  arrowType: 'round',
  size: 'large',
  duration: 500
  animation: 'scale'
})
```
