```js
tippy('.btn', {
  content: document.querySelector('#myTemplate')
})
```
