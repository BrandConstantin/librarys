```css
.tippy-popper[x-placement^='top'] .tippy-tooltip.honeybee-theme .tippy-arrow {
  /* Your styling here. */
}
```
