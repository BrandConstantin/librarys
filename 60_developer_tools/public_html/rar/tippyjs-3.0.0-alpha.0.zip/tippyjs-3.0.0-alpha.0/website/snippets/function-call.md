```js
tippy('button', { content: "I'm a tooltip!" })
```
