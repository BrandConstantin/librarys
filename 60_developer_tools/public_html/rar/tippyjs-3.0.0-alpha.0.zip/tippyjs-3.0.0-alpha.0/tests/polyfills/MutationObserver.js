global.window.MutationObserver = require('mutation-observer')
