global.window.focus = () => {}
global.window.scroll = () => {}
